# Apex Next.js 14 Starter

Deployed-ready Next.js 14 project.