export default function HomePage() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: '40px' }}>
      <h1>Welcome to Apex Next.js 14 App</h1>
      <p>This is a starter Next.js 14 App Router project ready for deployment.</p>
    </main>
  );
}
